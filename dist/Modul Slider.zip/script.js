let mySlider = new Slider({
	containerId: 'slider-container',
	slideClass: 'slide',
	title: 'My Slider',
	prevArrowId: 'prevArrow',
	nextArrowId: 'nextArrow',
	nav: 'false',
	autoplay: 'true',
});

let mySlider2 = new Slider({
	containerId: 'slider-container2',
	slideClass: 'slide',
	title: 'My Slider',
	prevArrowId: 'prevArrow',
	nextArrowId: 'nextArrow',
	nav: 'true',
	autoplay: 'false',
});




